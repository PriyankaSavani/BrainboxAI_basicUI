import React from 'react'

const Home = () => {
    return (
        <div>
            <h1 className='text-light'>Welcome Booking Service App</h1>
        </div>
    )
}

export default Home